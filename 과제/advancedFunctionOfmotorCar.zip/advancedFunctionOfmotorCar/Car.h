/*
 * 스마트카의 동작 처리를 위한 클래스의 헤더파일
 * 생성자에서 핀번호를 입력하며, 각 동작은 메서드로 처리
 * 작성자 : 김형래, 작성일: 2023.04.04
 */

#ifndef CAR_H
#define CAR_H
#define HORN_PIN 7
// 아두이노 동작을 위한 헤더파일
#include <Arduino.h>

// 클래스의 정의
class Car {
private: // 이 클래스에서만 접근 가능한 멤버
  // 핀번호
  int leftForward, leftBackward, rightForward, rightBackward;

public: // 다른 클래스에서도 접근 가능한 멤버
  // 생성자, 입력값은 모터드라이버의 핀번호
  Car(int, int, int, int);

  // 스마트카 동작
  GoForward(int);        // 전진
  GoBackward(int);       // 후진
  Stop();                // 정지
  TurnLeft(int);         // 제자리 좌회전
  TurnRight(int);        // 제자리 우회전
  ForwardLeft(int);      // 전진 좌회전
  ForwardRight(int);
  void Horn();     // 전진 우회전
};

#endif
