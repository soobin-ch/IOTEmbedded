/*
 * 스마트카의 동작 처리를 위한 클래스의 cpp 파일
 * 작성자: 김형래, 작성일: 2023.04.04
 */

// 아두이노 동작을 위한 헤더파일
#include "Car.h"

// 생성자, 입력값은 모터드라이버의 핀번호
Car::Car(int lf, int lb, int rf, int rb) {
  leftForward = lf;
  leftBackward = lb;
  rightForward = rf;
  rightBackward = rb;
}

// 스마트카 전진
Car::GoForward(int duty) {
  analogWrite(leftForward, duty);    // D
  analogWrite(leftBackward, 0);
  analogWrite(rightForward, duty);   // 2 UPI GU
  analogWrite(rightBackward, 0);
}

// 스마트카 후진
Car::GoBackward(int duty) {
  analogWrite(leftForward, 0);       // 37
  analogWrite(leftBackward, duty);
  analogWrite(rightForward, 0);      // UF ZU
  analogWrite(rightBackward, duty);
}

// 정지
Car::Stop() {
  analogWrite(leftForward, 0);       // analogWrite(leftBackward, 0);
  analogWrite(rightForward, 0);      // UP analogWrite(rightBackward, 0);
}

// 제자리 좌회전
Car::TurnLeft(int duty) {
  analogWrite(leftForward, 0);       // 20
  analogWrite(leftBackward, duty);
  analogWrite(rightForward, duty);   // 2E UP GU
  analogWrite(rightBackward, 0);
}

// 제자리 우회전
Car::TurnRight(int duty) {
  analogWrite(leftForward, duty);    // GU
  analogWrite(leftBackward, 0);
  analogWrite(rightForward, 0);      // 2 UAI SZ
  analogWrite(rightBackward, duty);
}
void Car::Horn() {
  tone(HORN_PIN, 1000);   // 1000Hz 음 재생
  delay(500);             // 0.5초
  noTone(HORN_PIN);       // 끔
}
